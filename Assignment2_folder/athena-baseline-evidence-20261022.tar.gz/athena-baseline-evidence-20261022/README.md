# Athena baseline evidence

Start with SUMMARY.md, then measurements/summary.csv, kernel-summary.csv and raw.csv.
The summary retains original Athena paths. manifest.csv maps every copied file to its original path and SHA-256 digest.

- measurements/ contains CSVs and metadata, with individual logs/ and predictions/ subdirectories.
- verification/ contains complete dataset and synthetic verification evidence.
- slurm/ contains the build and execution logs of jobs 3382502, 3382504 and 3382505.
- environment/ contains discovery output, discovery job logs, Slurm settings, accounting, submissions and the independent audit.
- provenance/ contains per-job git status and patches, and the combined change patch relative to the tested revision.
- source/ contains the tested source, scripts, tools, datasets and the Maple/Athena documentation snapshot.

Empty compiler temporary directories, binaries and Python caches are omitted. Original evidence is unchanged and nothing was rerun or altered.

All 36 measured prediction files should match the corresponding dataset's serial-b0-r1.predictions.txt file. Each dataset has three serial runs and three CUDA runs at each of 64, 128 and 256 threads per block, all on one NVIDIA A100-SXM4-80GB. Headline speedup uses mean Athena serial classification time divided by mean Athena GPU end-to-end classification time.

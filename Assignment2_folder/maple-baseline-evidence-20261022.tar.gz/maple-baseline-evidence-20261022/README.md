# Maple baseline evidence

Start with SUMMARY.md, then measurements/summary.csv and measurements/raw.csv.
The summary retains original Maple paths. manifest.csv maps every copied file to its original path and SHA-256 digest.

- measurements/ contains CSVs and metadata, with individual logs/ and predictions/ subdirectories.
- verification/ contains complete dataset and synthetic verification evidence.
- slurm/ contains the three build and execution logs.
- environment/ contains cluster settings, accounting, and the independent audit.
- provenance/ contains patches identifying changes after the tested revision.
- diagnostics/ preserves discovery issues and supporting inspection output.
- source/ contains source, datasets, and scripts for interpreting or reproducing the measurements.

Empty compiler temporary directories, binaries, and Python caches are omitted. Original evidence is unchanged. No measurements were rerun or altered.

All 36 measured prediction files should match the corresponding dataset's serial-b0-r1.predictions.txt file. Each dataset has three serial runs and three CUDA runs at each of 64, 128, and 256 threads per block. Headline speedup uses mean serial classification time divided by mean GPU end-to-end classification time.

# Athena MPI+CUDA verification evidence

Start with SUMMARY.md. manifest.csv maps every copied file to its original path and SHA-256 digest.

- measurements/ holds benchmark CSVs, metadata, individual logs and prediction files, if the evidence includes a benchmark.
- verification/ holds dataset and synthetic verification output.
- slurm/ holds the Slurm logs, including failed and diagnostic jobs.
- environment/ holds discovery output, submissions, audits and other supporting files.
- provenance/ holds per-job git status, patches and job descriptions.
- source/ holds the tested sources, scripts, tools and datasets.

Empty compiler temporary directories, private build work directories, binaries and Python caches are omitted. Originals are unchanged and nothing was rerun or altered.
